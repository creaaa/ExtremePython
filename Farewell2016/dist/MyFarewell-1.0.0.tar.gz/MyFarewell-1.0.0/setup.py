
from setuptools import setup, find_packages

setup(
    name='MyFarewell',
    version="1.0.0",                 
    description="さよなら2016年",
    long_description="2016年にお別れを言うだけのパッケージ",
    author='crea',
    author_email='masataka0504@gmail.com',
    license='MIT',
    classifiers=[
        "Development Status :: 1 - Planning"
    ],
    keywords='farewell',
    packages=['MyFawewell']
)