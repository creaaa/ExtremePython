
def farewell():
	print("Farewell 2016!")