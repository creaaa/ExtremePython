
from setuptools import setup, find_packages

setup(
    name='Farewell2016',
    version="0.0.1",                 
    description="さよなら2016年",
    long_description="2016年にお別れを言うだけのパッケージ",
    author='k.himeno',
    author_email='masataka0504@gmail.com',
    license='MIT',
    url='masatsune.me',
    classifiers=[
        "Development Status :: 1 - Planning"
    ],
    keywords='farewell'
)